#!/usr/bin/env python3
"""校验 JSONL 是否符合官方 train_public.schema.json。"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path

EMOTIONS = {
    "joy", "gratitude", "relaxed", "care", "pride", "neutral", "surprise", "mixed",
    "sadness", "loneliness", "anxiety", "anger", "fear", "disgust", "shame", "helplessness",
}
TRAITS = {
    "extroverted", "introverted", "open", "conservative", "high_conscientiousness",
    "casual", "agreeable", "assertive", "emotionally_stable", "sensitive",
}
INTERESTS = {
    "study_exam", "programming_technology", "reading_writing", "film_animation", "music",
    "games", "sports_fitness", "travel_outdoor", "pets", "social", "career_development", "art_design",
}
STYLES = {
    "brief", "detailed", "colloquial", "formal", "direct", "indirect", "humorous",
    "rational", "high_emotional_expression", "low_emotional_expression", "emoji_user",
}
CONV_RE = re.compile(r"^train_conv_[0-9]{6}$")
MEM_RE = re.compile(r"^mem_[0-9]{6}$")
ALLOWED_TOP = {"conversation_id", "turns", "prediction_points"}


def validate_row(row: dict, errors: list[str], ctx: str) -> None:
    if not isinstance(row, dict):
        errors.append(f"{ctx}: not object")
        return
    extra = set(row) - ALLOWED_TOP
    if extra:
        errors.append(f"{ctx}: extra top-level keys {sorted(extra)}")
    for req in ("conversation_id", "turns", "prediction_points"):
        if req not in row:
            errors.append(f"{ctx}: missing {req}")
    cid = row.get("conversation_id")
    if not isinstance(cid, str) or not CONV_RE.match(cid):
        errors.append(f"{ctx}: bad conversation_id {cid!r}")

    turns = row.get("turns")
    turn_ids = set()
    if not isinstance(turns, list) or not turns:
        errors.append(f"{ctx}: turns empty")
    else:
        for i, t in enumerate(turns):
            tc = f"{ctx}.turns[{i}]"
            if not isinstance(t, dict):
                errors.append(f"{tc}: not object")
                continue
            if set(t) - {"turn_id", "role", "content"}:
                errors.append(f"{tc}: extra keys")
            tid = t.get("turn_id")
            if not isinstance(tid, int) or tid < 1:
                errors.append(f"{tc}: bad turn_id")
            else:
                if tid in turn_ids:
                    errors.append(f"{tc}: duplicate turn_id {tid}")
                turn_ids.add(tid)
            if t.get("role") not in ("user", "assistant"):
                errors.append(f"{tc}: bad role {t.get('role')!r}")
            content = t.get("content")
            if not isinstance(content, str) or not content:
                errors.append(f"{tc}: empty content")

    pps = row.get("prediction_points")
    if not isinstance(pps, list):
        errors.append(f"{ctx}: prediction_points not array")
        return
    if not pps:
        return  # 官方 schema 允许空数组
    for j, pp in enumerate(pps):
        pc = f"{ctx}.pp[{j}]"
        if not isinstance(pp, dict):
            errors.append(f"{pc}: not object")
            continue
        if set(pp) - {"target_user_turn_id", "assistant_response_turn_id", "target"}:
            errors.append(f"{pc}: extra keys")
        uid = pp.get("target_user_turn_id")
        aid = pp.get("assistant_response_turn_id")
        if not isinstance(uid, int) or uid < 1:
            errors.append(f"{pc}: bad target_user_turn_id")
        elif uid not in turn_ids:
            errors.append(f"{pc}: target_user_turn_id {uid} not in turns")
        if not isinstance(aid, int) or aid < 1:
            errors.append(f"{pc}: bad assistant_response_turn_id")
        elif aid not in turn_ids:
            errors.append(f"{pc}: assistant_response_turn_id {aid} not in turns")

        target = pp.get("target")
        if not isinstance(target, dict):
            errors.append(f"{pc}: missing target")
            continue
        if set(target) - {"response_text", "emotion_label", "user_profile", "memory_refs"}:
            errors.append(f"{pc}.target: extra keys")
        rt = target.get("response_text")
        if not isinstance(rt, str) or not rt:
            errors.append(f"{pc}.target: empty response_text")
        emo = target.get("emotion_label")
        if emo not in EMOTIONS:
            errors.append(f"{pc}.target: bad emotion_label {emo!r}")
        up = target.get("user_profile")
        if not isinstance(up, dict):
            errors.append(f"{pc}.target: user_profile not object")
        else:
            for k, vocab in (
                ("personality_traits", TRAITS),
                ("interests", INTERESTS),
                ("style", STYLES),
            ):
                if k not in up:
                    errors.append(f"{pc}.target.user_profile missing {k}")
                    continue
                arr = up[k]
                if not isinstance(arr, list):
                    errors.append(f"{pc}.target.{k} not array")
                    continue
                seen = set()
                for item in arr:
                    if item not in vocab:
                        errors.append(f"{pc}.target.{k} bad item {item!r}")
                    if item in seen:
                        errors.append(f"{pc}.target.{k} duplicate {item!r}")
                    seen.add(item)
            if set(up) - {"personality_traits", "interests", "style"}:
                errors.append(f"{pc}.target.user_profile extra keys")
        refs = target.get("memory_refs")
        if not isinstance(refs, list):
            errors.append(f"{pc}.target: memory_refs not array")
        else:
            seen = set()
            for r in refs:
                if not isinstance(r, str) or not MEM_RE.match(r):
                    errors.append(f"{pc}.target: bad memory_ref {r!r}")
                if r in seen:
                    errors.append(f"{pc}.target: duplicate memory_ref {r!r}")
                seen.add(r)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs", nargs="+", type=Path)
    ap.add_argument("--max-errors", type=int, default=30)
    ap.add_argument("--report", type=Path, default=None)
    args = ap.parse_args()

    all_errors: list[str] = []
    summary = {}
    for path in args.inputs:
        errors: list[str] = []
        n = 0
        ids = set()
        emo = Counter()
        dup_ids = 0
        with path.open(encoding="utf-8") as f:
            for lineno, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                n += 1
                try:
                    row = json.loads(line)
                except json.JSONDecodeError as e:
                    errors.append(f"line {lineno}: JSON {e.msg}")
                    continue
                validate_row(row, errors, f"line {lineno}")
                cid = row.get("conversation_id") if isinstance(row, dict) else None
                if isinstance(cid, str):
                    if cid in ids:
                        dup_ids += 1
                        errors.append(f"line {lineno}: duplicate conversation_id {cid}")
                    ids.add(cid)
                if isinstance(row, dict):
                    for pp in row.get("prediction_points") or []:
                        if isinstance(pp, dict):
                            t = pp.get("target") or {}
                            if isinstance(t, dict) and t.get("emotion_label") in EMOTIONS:
                                emo[t["emotion_label"]] += 1
        summary[path.name] = {
            "rows": n,
            "unique_ids": len(ids),
            "dup_ids": dup_ids,
            "error_count": len(errors),
            "emotion_dist": dict(emo.most_common()),
            "ok": not errors,
        }
        all_errors.extend([f"[{path.name}] {e}" for e in errors])
        print(f"=== {path.name} ===")
        print(json.dumps(summary[path.name], ensure_ascii=False, indent=2))

    if all_errors:
        print(f"\n共 {len(all_errors)} 个问题，示例：")
        for e in all_errors[: args.max_errors]:
            print(" -", e)
    else:
        print("\n全部通过官方 schema 校验。")

    if args.report:
        args.report.write_text(
            json.dumps({"summary": summary, "errors": all_errors[:200]}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        print("报告:", args.report)

    return 1 if all_errors else 0


if __name__ == "__main__":
    sys.exit(main())
